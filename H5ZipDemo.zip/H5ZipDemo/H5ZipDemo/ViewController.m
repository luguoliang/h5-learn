//
//  ViewController.m
//  H5ZipDemo
//
//  Created by jackzhou on 16/3/21.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "ViewController.h"
#import "ZipArchive.h"
#import "H5ViewController.h"

#define PublicJs_File @"bestpay.html5.js"
#define Main_File @"main.html"
#define Properties_File @"MANIFEST.properties"

@interface ViewController ()
@property (strong, nonatomic) IBOutlet UIButton *loadLocalH5Btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}
- (IBAction)loadLocaH5:(id)sender {
    
    NSString *fileName = @"182_1.0.0.zip" ;
    NSString *zipPath = [[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"LocalH5Zip"] stringByAppendingPathComponent:fileName];
    if ([self installFromZipPath:zipPath fileManager:[NSFileManager defaultManager]]) {
        H5ViewController *h5View = [[H5ViewController alloc] init];
        h5View.path = [self appMainFilePath];
        [self presentViewController:h5View animated:YES completion:^{
            
        }];
    }
}

//Html5App包 主页地址
- (NSString *)appMainFilePath{
    
    //通过Properties文件去取MainFile
    NSString *appPropertyFilePath = [self appPropertyFilePath];
    if ([[NSFileManager defaultManager] fileExistsAtPath:appPropertyFilePath]) {
        NSString *appInstalledPath = [self folderPathAfterUnarchive];
        NSString *mainFileName = [self propertyMainItem];
        if (mainFileName) {
            return [appInstalledPath stringByAppendingPathComponent:mainFileName];
        }
    }
    return nil;
}

//安装应用
- (BOOL) installFromZipPath:(NSString *)zipFilePath fileManager:(NSFileManager *)fm{
    //解压路径
    NSString *installedPath = [self folderPathAfterUnarchive];
    
    //删除以前文件
    if ([fm fileExistsAtPath:installedPath]) {
        [fm removeItemAtPath:installedPath error:nil] ;
    }
    
    //文件是否存在
    if([fm fileExistsAtPath:zipFilePath]==NO) {
        return NO ;
    }
    
    //解压
    ZipArchive* zipArchive = [[ZipArchive alloc] init] ;
    if (![zipArchive UnzipOpenFile:zipFilePath] || ![zipArchive UnzipFileTo:installedPath overWrite:YES]) {
        return NO ;
    }
    //安装JS接口
    NSString* jsPath = [installedPath stringByAppendingPathComponent:PublicJs_File] ;
    return [self verifyPublicPortAtPath:jsPath fileManager:fm] ;
}

- (BOOL)verifyPublicPortAtPath:(NSString *)path fileManager:(NSFileManager *)fm {
    if ([fm fileExistsAtPath:path]==NO) {
        return [fm copyItemAtPath:[self publicPortPath] toPath:path error:NULL] ;
    }
    return YES ;
}

//解压文件地址
-(NSString *)folderPathAfterUnarchive{
    return [[self getDocumentFolderWithName:@"DownloadApps"] stringByAppendingPathComponent:@"182_1.0.0"];
}

//公共接口文件地址
-(NSString *)publicPortPath{
    return [[[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"LocalH5Zip"] stringByAppendingPathComponent:PublicJs_File];
}
//Html5App包 属性文件地址
-(NSString *)appPropertyFilePath{
    NSString *folderPath = [self folderPathAfterUnarchive];
    return [folderPath stringByAppendingPathComponent:Properties_File];
}

-(NSString *)getDocumentFolderWithName:(NSString *)name{
    NSString *filePath = [[self getDocumentPath] stringByAppendingPathComponent:name];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:filePath]) {
        //移动cache的文件到此
        NSString *cacheDir = [[self getCachePath] stringByAppendingPathComponent:name];
        BOOL success = NO ;
        if ([fm fileExistsAtPath:cacheDir]) {
            success = [fm moveItemAtPath:cacheDir toPath:filePath error:nil] ;
        }
        
        if(success==NO) {
            [fm createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
    return filePath;
}

- (NSString *)propertyMainItem{
    return [[self propertyDictionary] objectForKey:@"MAIN"];
}

- (NSDictionary *)propertyDictionary{
    NSString *propertyFile = [self appPropertyFilePath];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    
    NSString *contents = [[NSString alloc] initWithContentsOfFile:propertyFile encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *array = [contents componentsSeparatedByString:@"\n"];
    if ([array count]) {
        for (int i = 0; i < [array count]; i ++) {
            NSString *pStr = [array objectAtIndex:i];
            NSArray *kvArray = [pStr componentsSeparatedByString:@"="];
            if ([kvArray count] != 2) {
                continue;
            }
            NSString *key = [kvArray objectAtIndex:0];
            key = [key stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            key = [key stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            NSString *value = [kvArray objectAtIndex:1];
            value = [value stringByReplacingOccurrencesOfString:@"\b" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\r" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\t" withString:@""];
            value = [value stringByReplacingOccurrencesOfString:@"\0" withString:@""];
            
            [dic setObject:value forKey:key];
        }
    }
    return dic;
}


//获取沙盒Documents路径
-(NSString *)getDocumentPath {
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    return filePath;
}
//获取缓存cache路径
-(NSString *)getCachePath{
    NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    return filePath;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
