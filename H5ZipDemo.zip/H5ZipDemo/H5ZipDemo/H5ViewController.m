//
//  H5ViewController.m
//  H5ZipDemo
//
//  Created by jackzhou on 16/3/21.
//  Copyright © 2016年 BF. All rights reserved.
//

#import "H5ViewController.h"

#define ScreenWidth ([UIScreen mainScreen].bounds.size.width) //屏幕宽度
#define ScreenHeight ([UIScreen mainScreen].bounds.size.height) //屏幕高度

@interface H5ViewController ()<UIWebViewDelegate, UIScrollViewDelegate>
@property (nonatomic, strong) UIWebView *H5Webview;
@end

@implementation H5ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _H5Webview = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    _H5Webview.scalesPageToFit = YES;
    _H5Webview.scrollView.delegate = self;
    _H5Webview.delegate = self;
    [self.view addSubview:_H5Webview];
    
    NSURLRequest *request;
    if(_path){
        request = [NSURLRequest requestWithURL:[NSURL URLWithString:_path]];
        [_H5Webview loadRequest:request];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
